#!/bin/sh

FILE=$1
LANG=$2
echo FILE: $FILE
echo LANG: $LANG
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" > $1
echo "<language value=\"$LANG\"/>" >> $1