#!/bin/sh
#----------------------------------------------
# build_xcodeproj.sh
# 
# author : qizhiqiang
# date   : 2016-11-11
#----------------------------------------------

OUTPUT_NAME=$1

if [ -z $OUTPUT_NAME ]; then
    echo "ERROR : output name is empty (argument @1)"
    exit 1
fi

#if [ -d $OUTPUT_NAME ]; then
#    rm -rf $OUTPUT_NAME
#fi

# get channel

OLD_IFS=$IFS
IFS="_"
CHANNEL=(${OUTPUT_NAME})
IFS=$OLD_IFS

###############################
# utilities
###############################

string_is_contains()
{
    if [[ $1 =~ $2 ]]; then
        return 1
    else
        return 0
    fi
}

###############################
# export xcode project
###############################

PROJECT_PATH="`pwd`"
XCODE_PROJECT_PATH="$PROJECT_PATH/$OUTPUT_NAME"
RELATIVE_XCODE_PROJECT_PATH="$OUTPUT_NAME"
UNITY_PATH="/Applications/Unity/Unity.app/Contents/MacOS/Unity"

$UNITY_PATH -batchmode -projectPath $PROJECT_PATH -output=$OUTPUT_NAME -executeMethod PerformBuild.CommandLineBuild -quit -logFile $PROJECT_PATH/BuildLog/$OUTPUT_NAME.log

###############################
# modifications after xcode project generation
###############################

# Force touch

FORCE_TOUCH_INCLUDE_PATH="\#include \"3DTouchProxy.h\""
FORCE_TOUCH_PROXY_UPDATE_CODE="U3DTouchProxy::updateForce(touches);"
FORCE_TOUCH_CANCELLED_CODE="U3DTouchProxy::forceCancelled(touches);"

UNITY_VIEW_SOURCE="$RELATIVE_XCODE_PROJECT_PATH/Classes/UI/UnityView.mm"

sed -i "" "s#\#include \"UnityView.h\"#$FORCE_TOUCH_INCLUDE_PATH[WRAP]&#g" "$UNITY_VIEW_SOURCE"
sed -i "" "s#UnitySendTouchesBegin(touches, event);#&[WRAP]$FORCE_TOUCH_PROXY_UPDATE_CODE#g" "$UNITY_VIEW_SOURCE"
sed -i "" "s#UnitySendTouchesEnded(touches, event);#&[WRAP]$FORCE_TOUCH_CANCELLED_CODE#g"  "$UNITY_VIEW_SOURCE"
sed -i "" "s#UnitySendTouchesCancelled(touches, event);#&[WRAP]$FORCE_TOUCH_CANCELLED_CODE#g" "$UNITY_VIEW_SOURCE"
sed -i "" "s#UnitySendTouchesMoved(touches, event);#&[WRAP]$FORCE_TOUCH_PROXY_UPDATE_CODE#g" "$UNITY_VIEW_SOURCE"

sed -i "" 's/\[WRAP\]/\'$'\n/g' "$UNITY_VIEW_SOURCE"
echo "Modify UnityView.mm"


###############################
# modify zdir and icons
###############################

ICON_SRC_DIR="$PROJECT_PATH/../Tools/XUPorterSetting/Icon/$CHANNEL"
SHORTCUT_SRC_DIR="$PROJECT_PATH/../Tools/XUPorterSetting/Shortcut/$CHANNEL"
IMAGE_XCASSETS_DIR="$XCODE_PROJECT_PATH/Unity-iPhone/Images.xcassets"
APPICON_DIR="$IMAGE_XCASSETS_DIR/AppIcon.appiconset"

if [ ! -d $IMAGE_XCASSETS_DIR ]; then
    mkdir $IMAGE_XCASSETS_DIR
fi

if [ ! -d $APPICON_DIR ]; then
    mkdir $APPICON_DIR
fi

ICON_FILES=$(echo "$ICON_SRC_DIR/*.*")  

for FILE in $ICON_FILES
do
    cp -fr $FILE "$APPICON_DIR/"
done 

cp -fr "$SHORTCUT_SRC_DIR/" "$IMAGE_XCASSETS_DIR/"

###############################
# add browser assets
###############################

BROWSER_SRC_DIR="$PROJECT_PATH/../SDKLib/SDK/ZLUtility/browser"
BROWSER_DST_DIR="$IMAGE_XCASSETS_DIR/browser"

if [ ! -d "$BROWSER_DST_DIR" ]; then
    mkdir "$BROWSER_DST_DIR";
fi

if [ -d "$BROWSER_SRC_DIR" ]; then 
    rsync -aE -delete -progress "$BROWSER_SRC_DIR/" "$BROWSER_DST_DIR"
fi

###############################
# copy UnityAppController.mm
###############################
XCODE_PATH="$PROJECT_PATH/$RELATIVE_XCODE_PROJECT_PATH"
cd $PROJECT_PATH/../../../
echo $XCODE_PATH
echo $RELATIVE_XCODE_PROJECT_PATH
cp  "`pwd`"/backup/UnityAppController.mm $XCODE_PATH/Classes/UnityAppController.mm

#done
