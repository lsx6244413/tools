#!/bin/sh

FILE=$1
MAIN=$2
BACKUP=$3
GAMEID=$4
PLATFORM=$5
CHANNEL=$6
echo FILE: $FILE
echo MAIN: $MAIN
echo BACKUP: $BACKUP
echo GAMEID: $GAMEID
echo PLATFORM: $PLATFORM
echo CHANNEL: $CHANNEL
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" > $1
echo "<bilog main=\"$MAIN\" backup=\"$BACKUP\" gameid=\"$GAMEID\" platform=\"$PLATFORM\" channel=\"$CHANNEL\"/>" >> $1