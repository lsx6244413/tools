#!/bin/sh
#----------------------------------------------
# build_xcodeproj.sh
# 
# author : qizhiqiang
# date   : 2016-11-11
#----------------------------------------------

PROJECT=$1
BUNDLE_ID=$2 #bundle id, eg. com.loong.jpyyl
VERSION=$3 #version
BUILD=$4 #build version
PACK_VERSION=$5
OUTPUT=$6 #output path 
PROVISION=$7
BUILD_TYPE=$8 #appstore/adhoc/enterprise

PRODUCT_NAME=navalcreed

#PROJECT_VERSION_STRING="$VERSION(build$BUILD)"
ARCHIVE_PATH="$OUTPUT/app.xcarchive"

CODE_SIGN_IDENTITY_COMPANY="iPhone Distribution: Famous Heart Limited (7P3V2YS3W4)"
CODE_SIGN_IDENTITY_ENTERPRISE="iPhone Distribution: Tianjin Loong Technology Co., Ltd."

TEAM=7P3V2YS3W4

if [ "$BUILD_TYPE" == "appstore" ]; then
    CODE_SIGN_IDENTITY_NAME=$CODE_SIGN_IDENTITY_COMPANY
    ARCHIVE_OPTION_PLIST="appstore"
elif [ "$BUILD_TYPE" == "adhoc" ]; then
    CODE_SIGN_IDENTITY_NAME=$CODE_SIGN_IDENTITY_COMPANY
    ARCHIVE_OPTION_PLIST="adhoc"
fi

SH_PATH="../Tools/sh"

################################
# generate xcarchive
################################

PROJECT_PATH="$PROJECT/Unity-iPhone.xcodeproj"

PLIST_PATH="$PROJECT/Info.plist"

/usr/libexec/Plistbuddy -c "Set :CFBundleIdentifier $BUNDLE_ID" "$PLIST_PATH"

BUILD_ARCHIVE="xcodebuild archive -project \"$PROJECT_PATH\"
          -scheme \"Unity-iPhone\" 
          -configuration Release
          -sdk iphoneos
          -archivePath \"$ARCHIVE_PATH\"
          PRODUCT_NAME=\"$PRODUCT_NAME\"
          DEVELOPMENT_TEAM=\"$TEAM\"
          CODE_SIGN_IDENTITY=\"$CODE_SIGN_IDENTITY_NAME\"
          PROVISIONING_PROFILE_SPECIFIER=\"$PROVISION\"
          PRODUCT_BUNDLE_IDENTIFIER=\"$BUNDLE_ID\"
          "
echo $BUILD_ARCHIVE
eval $BUILD_ARCHIVE

################################
# generate ipa
################################

PLIST_PATH="$ARCHIVE_PATH/Info.plist"
INNER_PLIST_PATH="$ARCHIVE_PATH/Products/Applications/$PRODUCT_NAME.app/Info.plist"

echo $PLIST_PATH

/usr/libexec/Plistbuddy -c "Set :ApplicationProperties:CFBundleShortVersionString $VERSION" "$PLIST_PATH"
/usr/libexec/Plistbuddy -c "Set :ApplicationProperties:CFBundleVersion $BUILD" "$PLIST_PATH"

/usr/libexec/Plistbuddy -c "Set :CFBundleShortVersionString $VERSION" "$INNER_PLIST_PATH"
/usr/libexec/Plistbuddy -c "Set :CFBundleVersion $BUILD" "$INNER_PLIST_PATH"

LOCAL_VER_PATH="$ARCHIVE_PATH/Products/Applications/$PRODUCT_NAME.app/Data/Raw/config/local_version.xml"

/Library/Frameworks/Mono.framework/Versions/Current/Commands/mono ../Tools/PackVerModify_bin/PackVerModify.exe $LOCAL_VER_PATH $PACK_VERSION $VERSION $BUILD

BUILD_IPA="xcodebuild -exportArchive -archivePath \"$ARCHIVE_PATH\" -exportPath \"$OUTPUT\" -exportOptionsPlist $SH_PATH/$ARCHIVE_OPTION_PLIST.plist"

echo $BUILD_IPA
eval $BUILD_IPA

echo "done"

#../Tools/sh/build_archieve.sh zltest_bugly com.loong.jpyyl 1.0.0 1.0.10 "../../archives/com.loong.jpyyl/1.0.0(build1.0.10)" company
