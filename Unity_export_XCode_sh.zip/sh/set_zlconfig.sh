#!/bin/sh

FILE=$1
FLAG=$2
echo FILE: $FILE
echo FLAG: $FLAG

echo "{" > $1
echo "\"midasDebug\" : $FLAG" >> $1
echo "\"officalChannel\" : true" >>$1
echo "}" >> $1
