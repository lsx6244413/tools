#!/bin/sh

FILE=$1
PLATFORM=$2
SPECIAL_REGION=$3
echo FILE: $FILE
echo PLATFORM: $PLATFORM
echo SPECIAL_REGION: $SPECIAL_REGION
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" > $1
echo "<platform value=\"$PLATFORM\" special_region=\"$SPECIAL_REGION\"/>" >> $1